from pathlib import Path
p = Path('android/app/src/main/AndroidManifest.xml')
s = p.read_text()
permissions = '''    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
'''
if 'android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK' not in s:
    s = s.replace('<application', permissions + '    <application', 1)
service = '''
        <service
            android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService" />
            </intent-filter>
        </service>
        <receiver
            android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
'''
if 'com.ryanheise.audioservice.AudioService' not in s:
    s = s.replace('</application>', service + '    </application>', 1)
p.write_text(s)
