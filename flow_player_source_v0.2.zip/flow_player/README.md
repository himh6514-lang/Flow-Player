# Flow Player

一个以 Android 为目标的 Flutter 本地音乐播放器原型，采用深色流动玻璃界面。

## 当前实现
- 从系统文件选择器导入一个或多个本地音频文件
- 本地曲目列表、播放/暂停、上一首/下一首、进度拖动
- Android 媒体通知/锁屏媒体控制的 `audio_service` 基础接入
- 自然播放结束后自动切换下一首；单曲时从头继续
- 通知栏队列项目切换
- GitHub Actions 云端构建 APK 的工作流

## 尚未实现（不要把界面占位当成功能）
- 在线音乐搜索和在线播放：尚未接入可靠、合法且可持续的音源 API
- 均衡器、低音增强、虚拟环绕：尚未接入 Android 原生 AudioEffect
- Dolby Beta「大喇叭」：尚未验证其模块是否能识别并处理本播放器的音频会话
- 曲库持久化、歌词、封面自动读取、播放列表管理

## 云端构建 APK（只用手机也可操作）
1. 在 GitHub 新建一个空仓库。
2. 将本项目所有文件上传到仓库根目录（包含隐藏目录 `.github`）。
3. 打开仓库的 **Actions** 页面，选择 **Build Android APK**，点击 **Run workflow**。
4. 工作流完成后，进入该次运行页面底部的 **Artifacts**，下载 `flow-player-release-apk` 并解压安装。

第一次安装时 Android 可能提示允许安装未知来源应用。此 APK 是未签名发布密钥的调试式 release 构建产物，不适合直接作为长期商店发行包。

## 本地构建
需要 Flutter stable、Android SDK 和 JDK。执行：

```bash
flutter create --platforms=android --org app.flowplayer .
python3 tool/patch_android_manifest.py
flutter pub get
flutter build apk --release
```

输出路径：`build/app/outputs/flutter-apk/app-release.apk`

## 当前验证状态
源码已整理；本工作环境没有 Flutter/Dart SDK，因此没有声称 `flutter analyze` 或 APK 构建已通过。需要通过 GitHub Actions 实际构建后才能确认依赖/API 与 Android 打包兼容性。
