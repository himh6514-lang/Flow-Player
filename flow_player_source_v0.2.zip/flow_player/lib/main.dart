import 'dart:io';
import 'dart:ui';

import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

late final MusicHandler music;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  music = await AudioService.init(
    builder: MusicHandler.new,
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'app.flowplayer.audio',
      androidNotificationChannelName: 'Flow Player',
      androidNotificationOngoing: true,
    ),
  );
  runApp(const FlowPlayerApp());
}

class Track {
  Track({required this.path, required this.title})
      : id = path.hashCode.toString();
  final String id;
  final String path;
  final String title;
}

class MusicHandler extends BaseAudioHandler with QueueHandler, SeekHandler {
  final AudioPlayer _player = AudioPlayer();
  final List<Track> _tracks = [];
  int _index = 0;
  bool _loaded = false;
  bool _handlingCompletion = false;

  MusicHandler() {
    _player.playbackEventStream.listen((_) => _broadcastState());
    _player.currentIndexStream.listen((i) {
      if (i != null && i >= 0 && i < _tracks.length) {
        _index = i;
        _publishMediaItem();
      }
    });
    _player.durationStream.listen((_) => _publishMediaItem());
    _player.processingStateStream.listen((state) {
      if (state != ProcessingState.completed || _handlingCompletion) return;
      _handlingCompletion = true;
      () async {
        try {
          if (_tracks.length > 1) {
            await skipToNext();
          } else if (_tracks.length == 1) {
            await _player.seek(Duration.zero);
            await play();
          }
        } finally {
          _handlingCompletion = false;
        }
      }();
    });
    _configureAudio();
  }

  Future<void> _configureAudio() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
  }

  AudioPlayer get player => _player;
  List<Track> get tracks => List.unmodifiable(_tracks);

  Future<void> addFiles(List<PlatformFile> files) async {
    for (final f in files) {
      final p = f.path;
      if (p == null || !File(p).existsSync()) continue;
      if (_tracks.any((t) => t.path == p)) continue;
      _tracks.add(Track(path: p, title: f.name.replaceAll(RegExp(r'\.[^.]+$'), '')));
    }
    queue.add(_tracks.map(_toMediaItem).toList());
    if (_tracks.isNotEmpty && !_loaded) {
      await _loadIndex(0, autoplay: false);
    }
  }

  MediaItem _toMediaItem(Track t) => MediaItem(
        id: t.id,
        title: t.title,
        artist: '本地音乐',
        album: 'Flow Player',
      );

  Future<void> _publishMediaItem() async {
    if (_tracks.isEmpty || _index >= _tracks.length) return;
    mediaItem.add(_toMediaItem(_tracks[_index]).copyWith(duration: _player.duration));
  }

  Future<void> _loadIndex(int i, {bool autoplay = true}) async {
    if (i < 0 || i >= _tracks.length) return;
    _index = i;
    _handlingCompletion = true;
    try {
      await _player.setFilePath(_tracks[i].path);
    } finally {
      _handlingCompletion = false;
    }
    _loaded = true;
    await _publishMediaItem();
    if (autoplay) await play();
  }

  Future<void> playIndex(int i) => _loadIndex(i);

  void _broadcastState() {
    playbackState.add(playbackState.value.copyWith(
      controls: [
        MediaControl.skipToPrevious,
        _player.playing ? MediaControl.pause : MediaControl.play,
        MediaControl.skipToNext,
        MediaControl.stop,
      ],
      systemActions: const {MediaAction.seek},
      androidCompactActionIndices: const [0, 1, 2],
      processingState: const {
        ProcessingState.idle: AudioProcessingState.idle,
        ProcessingState.loading: AudioProcessingState.loading,
        ProcessingState.buffering: AudioProcessingState.buffering,
        ProcessingState.ready: AudioProcessingState.ready,
        ProcessingState.completed: AudioProcessingState.completed,
      }[_player.processingState]!,
      playing: _player.playing,
      updatePosition: _player.position,
      bufferedPosition: _player.bufferedPosition,
      speed: _player.speed,
      queueIndex: _index,
    ));
  }

  @override
  Future<void> play() => _player.play();
  @override
  Future<void> pause() => _player.pause();
  @override
  Future<void> stop() async {
    await _player.stop();
    await super.stop();
  }
  @override
  Future<void> seek(Duration position) => _player.seek(position);
  @override
  Future<void> skipToQueueItem(int index) async {
    await _loadIndex(index);
  }
  @override
  Future<void> skipToNext() async {
    if (_tracks.isNotEmpty) await _loadIndex((_index + 1) % _tracks.length);
  }
  @override
  Future<void> skipToPrevious() async {
    if (_tracks.isNotEmpty) await _loadIndex((_index - 1 + _tracks.length) % _tracks.length);
  }
}

class FlowPlayerApp extends StatelessWidget {
  const FlowPlayerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: const Color(0xff10131b),
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff9d8cff), brightness: Brightness.dark),
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;

  Future<void> _pickMusic() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: true,
      withData: false,
    );
    if (result == null) return;
    try {
      await music.addFiles(result.files);
      if (mounted) setState(() {});
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('导入音乐失败：$error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        const _AmbientBackground(),
        SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 12),
              child: Row(children: [
                const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('FLOW', style: TextStyle(letterSpacing: 4, fontSize: 12, color: Colors.white60)),
                  SizedBox(height: 3),
                  Text('音乐，随心流动', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
                ]),
                const Spacer(),
                _GlassButton(icon: Icons.add_rounded, onTap: _pickMusic),
              ]),
            ),
            Expanded(child: _page()),
            _NowPlayingBar(onTap: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              backgroundColor: Colors.transparent,
              builder: (_) => const _PlayerSheet(),
            )),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 8, 22, 12),
              child: _GlassPanel(
                radius: 28,
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _NavItem(icon: Icons.auto_awesome_rounded, label: '发现', selected: tab == 0, onTap: () => setState(() => tab = 0)),
                  _NavItem(icon: Icons.library_music_rounded, label: '本地', selected: tab == 1, onTap: () => setState(() => tab = 1)),
                  _NavItem(icon: Icons.graphic_eq_rounded, label: '音效', selected: tab == 2, onTap: () => setState(() => tab = 2)),
                ]),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _page() {
    if (tab == 1) return _LibraryPage(onPick: _pickMusic);
    if (tab == 2) return const _EffectsPage();
    return const _DiscoverPage();
  }
}

class _DiscoverPage extends StatelessWidget {
  const _DiscoverPage();
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(22, 8, 22, 20), children: [
        const Text('YOUR SPACE', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontSize: 11)),
        const SizedBox(height: 12),
        _GlassPanel(radius: 30, padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('把喜欢的音乐，\n装进自己的空间。', style: TextStyle(fontSize: 27, height: 1.25, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          const Text('先从手机本地曲库开始。在线音源接入将在后续版本加入。', style: TextStyle(color: Colors.white60, height: 1.5)),
          const SizedBox(height: 20),
          const _OrbArtwork(size: 156),
        ])),
        const SizedBox(height: 20),
        const Text('最近播放', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        StreamBuilder<MediaItem?>(stream: music.mediaItem, builder: (_, s) => _GlassPanel(child: ListTile(
          leading: const Icon(Icons.album_rounded, size: 38, color: Color(0xffb6aaff)),
          title: Text(s.data?.title ?? '还没有播放记录'),
          subtitle: Text(s.data?.artist ?? '添加本地音乐即可开始'),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _PlayerSheet())),
        ))),
      ]);
}

class _LibraryPage extends StatelessWidget {
  const _LibraryPage({required this.onPick});
  final VoidCallback onPick;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(22, 8, 22, 20), children: [
          Row(children: [const Text('本地曲库', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700)), const Spacer(), Text('${music.tracks.length} 首', style: const TextStyle(color: Colors.white54))]),
          const SizedBox(height: 14),
          if (music.tracks.isEmpty) _GlassPanel(padding: const EdgeInsets.all(22), child: Column(children: [const Icon(Icons.library_music_outlined, size: 48, color: Colors.white54), const SizedBox(height: 10), const Text('曲库还是空的'), const SizedBox(height: 12), FilledButton.icon(onPressed: onPick, icon: const Icon(Icons.add), label: const Text('选择音乐文件'))]))
          else ...music.tracks.asMap().entries.map((e) => _GlassPanel(margin: const EdgeInsets.only(bottom: 8), child: ListTile(
            leading: const _MiniArtwork(), title: Text(e.value.title, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: const Text('本地文件'),
            trailing: const Icon(Icons.play_circle_fill_rounded, color: Color(0xffb9aaff), size: 30),
            onTap: () => music.playIndex(e.key),
          ))),
        ]);
}

class _EffectsPage extends StatelessWidget {
  const _EffectsPage();
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(22), children: [
        const Text('音效实验室', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        const Text('音效控制需要接入 Android AudioEffect 原生会话。当前版本先搭建界面，尚未启用处理链。', style: TextStyle(color: Colors.white60, height: 1.5)),
        const SizedBox(height: 16),
        for (final item in ['均衡器', '低音增强', '虚拟环绕', '响度补偿', 'Dolby / 大喇叭兼容'])
          _GlassPanel(margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: const Icon(Icons.graphic_eq_rounded, color: Color(0xffb9aaff)), title: Text(item), trailing: const Icon(Icons.lock_clock_rounded, color: Colors.white38))),
      ]);
}

class _NowPlayingBar extends StatelessWidget {
  const _NowPlayingBar({required this.onTap});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => StreamBuilder<MediaItem?>(stream: music.mediaItem, builder: (_, s) => _GlassPanel(
        margin: const EdgeInsets.symmetric(horizontal: 18), radius: 22,
        child: ListTile(onTap: onTap, leading: const _MiniArtwork(), title: Text(s.data?.title ?? '选择一首音乐开始', maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: Text(s.data?.artist ?? 'FLOW PLAYER'), trailing: StreamBuilder<bool>(stream: music.player.playingStream, builder: (_, p) => IconButton(onPressed: () => p.data == true ? music.pause() : music.play(), icon: Icon(p.data == true ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 30))))));
}

class _PlayerSheet extends StatelessWidget {
  const _PlayerSheet();
  String _time(Duration d) => '${d.inMinutes.remainder(60).toString().padLeft(2, '0')}:${d.inSeconds.remainder(60).toString().padLeft(2, '0')}';
  @override
  Widget build(BuildContext context) => Container(
        height: MediaQuery.of(context).size.height * .82,
        decoration: const BoxDecoration(color: Color(0xff171a25), borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
        child: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
          Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(4))),
          const Spacer(), const _OrbArtwork(size: 250), const SizedBox(height: 32),
          StreamBuilder<MediaItem?>(stream: music.mediaItem, builder: (_, s) => Column(children: [Text(s.data?.title ?? '尚未选择歌曲', textAlign: TextAlign.center, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w700)), const SizedBox(height: 6), Text(s.data?.artist ?? 'FLOW PLAYER', style: const TextStyle(color: Colors.white54))])),
          const SizedBox(height: 26),
          StreamBuilder<Duration>(stream: music.player.positionStream, builder: (_, p) => StreamBuilder<Duration?>(stream: music.player.durationStream, builder: (_, d) {
            final total = d.data ?? Duration.zero; final pos = p.data ?? Duration.zero;
            return Column(children: [Slider(value: total.inMilliseconds == 0 ? 0 : pos.inMilliseconds.clamp(0, total.inMilliseconds).toDouble(), max: total.inMilliseconds < 1 ? 1 : total.inMilliseconds.toDouble(), onChanged: (v) => music.seek(Duration(milliseconds: v.round()))), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_time(pos), style: const TextStyle(color: Colors.white54)), Text(_time(total), style: const TextStyle(color: Colors.white54))])]);
          })),
          const SizedBox(height: 14),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [IconButton(iconSize: 34, onPressed: music.skipToPrevious, icon: const Icon(Icons.skip_previous_rounded)), StreamBuilder<bool>(stream: music.player.playingStream, builder: (_, s) => IconButton(iconSize: 62, onPressed: () => s.data == true ? music.pause() : music.play(), icon: Icon(s.data == true ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, color: const Color(0xffc3b4ff)))), IconButton(iconSize: 34, onPressed: music.skipToNext, icon: const Icon(Icons.skip_next_rounded))]),
          const Spacer(),
        ]))),
      );
}

class _AmbientBackground extends StatelessWidget {
  const _AmbientBackground();
  @override
  Widget build(BuildContext context) => Positioned.fill(child: Stack(children: [
        Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xff22233a), Color(0xff10131b), Color(0xff171b2b)]))),
        Positioned(top: -90, right: -60, child: _Glow(color: const Color(0xff7566c9).withOpacity(.30), size: 250)),
        Positioned(bottom: 90, left: -90, child: _Glow(color: const Color(0xff3f8299).withOpacity(.18), size: 260)),
      ]));
}

class _Glow extends StatelessWidget {
  const _Glow({required this.color, required this.size});
  final Color color; final double size;
  @override
  Widget build(BuildContext context) => ImageFiltered(imageFilter: ImageFilter.blur(sigmaX: 45, sigmaY: 45), child: Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color)));
}

class _GlassPanel extends StatelessWidget {
  const _GlassPanel({required this.child, this.margin, this.padding = EdgeInsets.zero, this.radius = 22});
  final Widget child; final EdgeInsetsGeometry? margin; final EdgeInsetsGeometry padding; final double radius;
  @override
  Widget build(BuildContext context) => Container(margin: margin, decoration: BoxDecoration(borderRadius: BorderRadius.circular(radius), border: Border.all(color: Colors.white.withOpacity(.11)), color: Colors.white.withOpacity(.055)), child: ClipRRect(borderRadius: BorderRadius.circular(radius), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18), child: Padding(padding: padding, child: child))));
}

class _GlassButton extends StatelessWidget {
  const _GlassButton({required this.icon, required this.onTap}); final IconData icon; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: _GlassPanel(padding: const EdgeInsets.all(12), radius: 18, child: Icon(icon)));
}

class _MiniArtwork extends StatelessWidget {
  const _MiniArtwork();
  @override
  Widget build(BuildContext context) => Container(width: 46, height: 46, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(colors: [Color(0xff9b8be8), Color(0xff4b668f)])), child: const Icon(Icons.music_note_rounded, color: Colors.white));
}

class _OrbArtwork extends StatelessWidget {
  const _OrbArtwork({required this.size}); final double size;
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, gradient: const RadialGradient(colors: [Color(0xffded5ff), Color(0xff9180d7), Color(0xff30334e)], stops: [0, .35, 1]), boxShadow: [BoxShadow(color: const Color(0xff9884e7).withOpacity(.35), blurRadius: 42, spreadRadius: 2)]), child: Center(child: Container(width: size * .28, height: size * .28, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xff171a25), border: Border.all(color: Colors.white.withOpacity(.3), width: 2)), child: const Icon(Icons.graphic_eq_rounded, color: Colors.white70))));
}

class _NavItem extends StatelessWidget {
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap});
  final IconData icon; final String label; final bool selected; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, color: selected ? const Color(0xffc6b9ff) : Colors.white54), const SizedBox(height: 3), Text(label, style: TextStyle(fontSize: 11, color: selected ? Colors.white : Colors.white54))])));
}
